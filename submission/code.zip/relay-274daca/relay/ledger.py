"""The shared daily Groq budget, enforced in code.

Every real Groq call goes through ``BudgetedClient``:
  1. ``Ledger.reserve`` checks every cap that applies, counting calls still in flight. It refuses
     (raises ``BudgetExceeded``) before anything is sent if the call could break a cap.
  2. The call runs on ``relay.llm.LLMClient``.
  3. ``Ledger.settle`` appends one line to ``results/ledger/groq_calls.jsonl`` and flushes it, so
     it survives a crash of this process. This happens for every call, including timeouts and
     cancellations. It is fsynced on close, not per line: an fsync on this machine's data disk
     takes ~30-60 ms and would block the event loop, delaying the timestamps of calls in flight.

Caps come from ``config/budget.toml`` as fractions of the documented daily allowance
(``data/limits_documented.json``):
  * an account-wide safety net over all real calls (scope "*");
  * per-run caps, e.g. the probe's 10% (scope "probe").
The account cap's fraction can be raised for one run with the environment variable
``RELAY_ACCOUNT_CAP_FRACTION`` (at most 1.0, i.e. the documented limit itself). It is announced on
stderr and every ledger line written under it carries ``account_cap_fraction``, so the override is
on the record. The stand-in and per-run caps (e.g. the probe's) are never affected.
By default they are counted over a **rolling 24 h window**. ``RELAY_LEDGER_ACCOUNTING=refill``
switches one run to a refilling bucket instead: each model's charges drain continuously at
cap / window (the behaviour measured for Groq's daily request counter, findings 2026-11-11); also
recorded on every ledger line (``ledger_accounting``). Per-run total-request caps stay rolling.
The rolling window is at least as strict as a fixed daily reset at any hour or a refilling bucket.

Charging is conservative until the probe tells us how Groq really counts:
  * connect error (the server was never reached): 0 requests, 0 tokens
  * HTTP 4xx (429 limit, 413 too large, 400 bad parameters): 1 request, estimated prompt tokens.
    Assumes a rejected call isn't charged its max_tokens; the probe checks this.
  * anything else: 1 request, max(estimated prompt + max_tokens, reported total usage).
    Correct whether Groq charges max_tokens at admission or actual usage.
A call without ``max_tokens`` is refused: unbounded output can't be reserved.

The key is shared, so other users may be spending the same allowance. After each call the
server's own ``x-ratelimit-remaining-requests`` (RPD) is compared with a floor. Below it, the
ledger halts all further real calls with a reason.

Only one process may hold the ledger at a time (OS file lock on ``groq_calls.lock``), so two
scripts can't both pass the same cap.

Status:  .venv\\Scripts\\python -m relay.ledger
"""
from __future__ import annotations

import itertools
import json
import math
import os
import sys
import time
import tomllib
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable

from relay.llm import CONNECT_ERROR, CallRecord, LLMClient

ROOT = Path(__file__).resolve().parents[1]
DEFAULT_LEDGER = ROOT / "results" / "ledger" / "groq_calls.jsonl"
DEFAULT_BUDGET = ROOT / "config" / "budget.toml"
DOCUMENTED = ROOT / "data" / "limits_documented.json"


REPORTED = "reported usage (findings Q2: Groq releases the admission hold down to what was used)"


def charge_of(e: dict[str, Any]) -> int:
    """Tokens a ledger entry counts against the caps. The file is append-only, so entries written
    under the earlier rule (max(estimate + max_tokens, usage)) are re-read with the current one:
    a completed 200 that reported its usage counts that usage; anything else keeps its conservative
    charge. Changed 2026-11-10 at the author's request (it was ~2x real usage on long drafts)."""
    u = e.get("usage_total_tokens")
    if e.get("status") == 401:      # invalid key: Groq identified no account, so none was charged
        return 0
    if e.get("status") == 200 and e.get("outcome") == "ok" and isinstance(u, int):
        return u
    return int(e.get("charged_tokens") or 0)


def requests_of(e: dict[str, Any]) -> int:
    """Requests a ledger entry counts against the caps (0 for a 401, like charge_of)."""
    return 0 if e.get("status") == 401 else int(e.get("charged_requests") or 0)


class BudgetExceeded(Exception):
    """Raised instead of sending a call that could break a cap."""


@dataclass(frozen=True)
class ModelCap:
    requests: int
    tokens: int


@dataclass(frozen=True)
class Cap:
    name: str
    scope: str                       # "*" = every real call; otherwise only calls in this scope
    models: dict[str, ModelCap]      # a model not listed here is refused under this cap
    total_requests: int | None = None

    def applies(self, scope: str) -> bool:
        return self.scope == "*" or self.scope == scope


@dataclass
class Budget:
    caps: list[Cap]
    window_hours: float = 24.0
    min_remaining_requests_fraction: float | None = None
    # Tokens the server's chat template adds that we can't see in the messages. Must over-estimate,
    # so that a reservation is an upper bound on what a call can be charged. A measured per-model
    # value can replace it (Ledger.set_prompt_overhead).
    prompt_overhead_tokens: int = 16
    # set only when RELAY_ACCOUNT_CAP_FRACTION overrides the "account" cap for this run
    account_cap_fraction: float | None = None
    # "rolling" (default: a spend counts for exactly window_hours) or "refill" (drains at cap/window)
    accounting: str = "rolling"


ACCOUNT_CAP_ENV = "RELAY_ACCOUNT_CAP_FRACTION"
ACCOUNTING_ENV = "RELAY_LEDGER_ACCOUNTING"


def load_budget(budget_path: Path = DEFAULT_BUDGET, documented_path: Path = DOCUMENTED) -> Budget:
    cfg = tomllib.loads(budget_path.read_text(encoding="utf-8"))
    doc = json.loads(documented_path.read_text(encoding="utf-8"))["models"]
    caps = []
    override = None
    raw = os.environ.get(ACCOUNT_CAP_ENV, "").strip()
    if raw:
        override = float(raw)
        if not 0 < override <= 1.0:
            raise ValueError(f"{ACCOUNT_CAP_ENV}={raw}: must be in (0, 1]; the documented limit is the ceiling")
        print(f"ledger: account cap overridden to {override:.0%} of the documented daily limits "
              f"({ACCOUNT_CAP_ENV}); recorded on every ledger line", file=sys.stderr)
    for c in cfg["cap"]:
        frac = float(c["fraction_of_documented"])
        if override is not None and c["name"] == "account":
            frac = override
        models = {m: ModelCap(math.floor(doc[m]["rpd"] * frac), math.floor(doc[m]["tpd"] * frac))
                  for m in c["models"]}
        caps.append(Cap(c["name"], c.get("scope", "*"), models, c.get("total_requests")))
    floor = cfg.get("server_floor", {}).get("min_remaining_requests_fraction")
    accounting = os.environ.get(ACCOUNTING_ENV, "").strip() or str(cfg.get("accounting", "rolling"))
    if accounting not in ("rolling", "refill"):
        raise ValueError(f"{ACCOUNTING_ENV}={accounting}: must be 'rolling' or 'refill'")
    if accounting != "rolling":
        print(f"ledger: {accounting} accounting (caps drain continuously at cap/window) "
              f"({ACCOUNTING_ENV}); recorded on every ledger line", file=sys.stderr)
    return Budget(caps, float(cfg.get("window_hours", 24)), floor,
                  int(cfg.get("prompt_overhead_tokens", 16)), override, accounting)


def prompt_chars(payload: dict[str, Any]) -> int:
    return sum(len(m.get("content") or "") for m in payload.get("messages") or [] if isinstance(m, dict))


def estimate_prompt_tokens(payload: dict[str, Any], overhead: int = 16) -> int:
    """Over-estimate on purpose (~3 chars/token; English is ~4), plus 8 per message, plus the
    chat template's hidden ``overhead``. Settlement uses reported usage whenever it is larger."""
    msgs = [m for m in payload.get("messages") or [] if isinstance(m, dict)]
    return math.ceil(prompt_chars(payload) / 3) + 8 * len(msgs) + overhead


def max_output_tokens(payload: dict[str, Any]) -> int:
    mx = payload.get("max_completion_tokens") or payload.get("max_tokens")
    if not isinstance(mx, int) or mx <= 0:
        raise BudgetExceeded("budgeted calls must set max_tokens (unbounded output cannot be reserved)")
    return mx


@dataclass
class Reservation:
    id: int
    model: str
    scope: str
    phase: str
    est_prompt_tokens: int
    max_tokens: int
    reserved_tokens: int


def _lock(path: Path):
    f = open(path, "a+b")
    try:
        if os.name == "nt":
            import msvcrt
            f.seek(0)
            msvcrt.locking(f.fileno(), msvcrt.LK_NBLCK, 1)
        else:
            import fcntl
            fcntl.flock(f, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except OSError:
        f.close()
        raise BudgetExceeded(f"another process holds {path.name}; only one budgeted process at a time")
    return f


def _unlock(f) -> None:
    try:
        if os.name == "nt":
            import msvcrt
            f.seek(0)
            msvcrt.locking(f.fileno(), msvcrt.LK_UNLCK, 1)
    finally:
        f.close()


def _int_header(rec: CallRecord, name: str) -> int | None:
    v = rec.header(name)
    try:
        return int(v) if v is not None else None
    except ValueError:
        return None


LEGACY_ACCOUNT = "key1"      # entries written before accounts were recorded: the first key


class Ledger:
    def __init__(self, budget: Budget, path: Path = DEFAULT_LEDGER,
                 clock: Callable[[], float] = time.time, account: str | None = None) -> None:
        """``account``: a label for the API key in use (relay.real.account_label; never the key). Caps
        count only that account's entries (entries without one belong to LEGACY_ACCOUNT), because Groq's
        limits belong to the key's organization. None counts every entry (the conservative default)."""
        self.account = account
        self.budget = budget
        self.path = path
        self.clock = clock
        path.parent.mkdir(parents=True, exist_ok=True)
        self._lockfile = _lock(path.with_suffix(".lock"))
        self.entries: list[dict[str, Any]] = []
        if path.exists():
            for line in path.read_text(encoding="utf-8").splitlines():
                if line.strip():
                    self.entries.append(json.loads(line))
        self.inflight: dict[int, Reservation] = {}
        self._ids = itertools.count(1)
        self.halted: str | None = None
        self.prompt_overhead: dict[str, int] = {}   # measured per model; else the budget default

    # --------------------------------------------------------------- lifecycle
    def close(self) -> None:
        if self.path.exists():
            with self.path.open("a", encoding="utf-8") as f:
                os.fsync(f.fileno())
        if self._lockfile is not None:
            _unlock(self._lockfile)
            self._lockfile = None

    def __enter__(self) -> "Ledger":
        return self

    def __exit__(self, *exc) -> None:
        self.close()

    # --------------------------------------------------------------- accounting
    def overhead_for(self, model: str) -> int:
        return self.prompt_overhead.get(model, self.budget.prompt_overhead_tokens)

    def set_prompt_overhead(self, model: str, tokens: int) -> None:
        """Use a measured template overhead for ``model`` (the caller adds its own safety margin)."""
        self.prompt_overhead[model] = int(tokens)

    def estimate(self, payload: dict[str, Any]) -> int:
        return estimate_prompt_tokens(payload, self.overhead_for(payload.get("model")))

    def worst_charge(self, payload: dict[str, Any]) -> int:
        """What reserving ``payload`` would hold: estimated prompt + max_tokens."""
        return self.estimate(payload) + max_output_tokens(payload)

    def headroom(self, scope: str, model: str) -> dict[str, int]:
        """Smallest requests/tokens left for ``model`` across every cap that applies to ``scope``."""
        req = tok = tot = 10 ** 12
        for cap in self.budget.caps:
            if not cap.applies(scope) or model not in cap.models:
                continue
            u = self.usage(cap)
            mc = cap.models[model]
            req = min(req, mc.requests - u["models"][model]["requests"])
            tok = min(tok, mc.tokens - u["models"][model]["tokens"])
            if cap.total_requests is not None:
                tot = min(tot, cap.total_requests - u["total_requests"])
        return {"requests": req, "tokens": tok, "total_requests": tot}

    def _refill_levels(self, cap: Cap) -> dict[str, dict[str, int]]:
        """Per-model level of a bucket that every charge fills and that drains continuously at
        cap / window (never below 0), replayed over this account's entries up to now."""
        w = self.budget.window_hours * 3600
        now = self.clock()
        lv: dict[str, list[float]] = {}           # model -> [requests, tokens, ts of last update]
        mine = [e for e in self.entries
                if (self.account is None or e.get("account", LEGACY_ACCOUNT) == self.account)
                and cap.applies(e["scope"])]
        for e in sorted(mine, key=lambda e: e["ts"]):
            mc = cap.models.get(e["model"])
            r = lv.setdefault(e["model"], [0.0, 0.0, e["ts"]])
            if mc is not None:
                dt = max(0.0, e["ts"] - r[2])
                r[0] = max(0.0, r[0] - mc.requests * dt / w)
                r[1] = max(0.0, r[1] - mc.tokens * dt / w)
            r[0] += requests_of(e)
            r[1] += charge_of(e)
            r[2] = e["ts"]
        per = {m: {"requests": 0, "tokens": 0} for m in cap.models}
        for m, (rq, tk, t) in lv.items():
            mc = cap.models.get(m)
            if mc is not None:
                dt = max(0.0, now - t)
                rq, tk = max(0.0, rq - mc.requests * dt / w), max(0.0, tk - mc.tokens * dt / w)
            per[m] = {"requests": math.ceil(rq), "tokens": math.ceil(tk)}
        return per

    def _in_window(self) -> list[dict[str, Any]]:
        cutoff = self.clock() - self.budget.window_hours * 3600
        return [e for e in self.entries if e["ts"] >= cutoff
                and (self.account is None or e.get("account", LEGACY_ACCOUNT) == self.account)]

    def usage(self, cap: Cap) -> dict[str, Any]:
        """Requests/tokens charged in the window under ``cap``, plus calls still in flight."""
        per = {m: {"requests": 0, "tokens": 0} for m in cap.models}
        total = 0
        for e in self._in_window():
            if not cap.applies(e["scope"]):
                continue
            p = per.setdefault(e["model"], {"requests": 0, "tokens": 0})
            p["requests"] += requests_of(e)
            p["tokens"] += charge_of(e)
            total += requests_of(e)
        if self.budget.accounting == "refill":
            per = self._refill_levels(cap)
        for r in self.inflight.values():
            if not cap.applies(r.scope):
                continue
            p = per.setdefault(r.model, {"requests": 0, "tokens": 0})
            p["requests"] += 1
            p["tokens"] += r.reserved_tokens
            total += 1
        return {"models": per, "total_requests": total}

    def reserve(self, payload: dict[str, Any], scope: str, phase: str) -> Reservation:
        if self.halted:
            raise BudgetExceeded(f"ledger halted: {self.halted}")
        model = payload.get("model")
        est = estimate_prompt_tokens(payload, self.overhead_for(model))
        mx = max_output_tokens(payload)
        need = est + mx
        applicable = [c for c in self.budget.caps if c.applies(scope)]
        if not applicable:
            raise BudgetExceeded(f"no cap covers scope {scope!r}; refusing an unbudgeted real call")
        for cap in applicable:
            if model not in cap.models:
                raise BudgetExceeded(f"model {model!r} is not allowed under cap {cap.name!r}")
            u = self.usage(cap)
            mc = cap.models[model]
            mu = u["models"][model]
            if mu["requests"] + 1 > mc.requests:
                raise BudgetExceeded(f"cap {cap.name!r}: {model} requests {mu['requests']}/{mc.requests}")
            if mu["tokens"] + need > mc.tokens:
                raise BudgetExceeded(f"cap {cap.name!r}: {model} tokens {mu['tokens']}+{need} > {mc.tokens}")
            if cap.total_requests is not None and u["total_requests"] + 1 > cap.total_requests:
                raise BudgetExceeded(f"cap {cap.name!r}: total requests {u['total_requests']}/{cap.total_requests}")
        r = Reservation(next(self._ids), model, scope, phase, est, mx, need)
        self.inflight[r.id] = r
        return r

    def release(self, r: Reservation) -> None:
        """Drop a reservation for a call that was never sent."""
        self.inflight.pop(r.id, None)

    def settle(self, r: Reservation, rec: CallRecord, extra: dict[str, Any] | None = None) -> dict[str, Any]:
        self.inflight.pop(r.id, None)
        usage_total = (rec.usage or {}).get("total_tokens")
        if rec.outcome == CONNECT_ERROR:
            req, tok, basis = 0, 0, "never reached the server"
        elif rec.status == 401:
            # the key was rejected: no account was identified, so no account's budget was spent
            req, tok, basis = 0, 0, "401: invalid API key, no account charged"
        elif rec.status is not None and 400 <= rec.status < 500:
            # rejected before any generation (429 limit, 413 too large, 400 bad params)
            req, tok, basis = 1, r.est_prompt_tokens, f"{rec.status}: rejected, prompt estimate only (assumption; probe P2/P3 check)"
        elif rec.status == 200 and rec.outcome == "ok" and isinstance(usage_total, int):
            # Groq releases what admission held down to real usage (findings Q2), so charge that
            req, tok, basis = 1, usage_total, REPORTED
        else:
            # no usage reported (timeout, stall, cancelled, stream error): we can't know, stay conservative
            req = 1
            tok = max(r.reserved_tokens, int(usage_total or 0))
            basis = "max(prompt estimate + max_tokens, reported usage)"
        now = self.clock()
        entry = {
            "ts": now,
            "ts_iso": datetime.fromtimestamp(now, timezone.utc).isoformat(timespec="milliseconds"),
            "scope": r.scope,
            "phase": r.phase,
            "account": self.account,
            **({"account_cap_fraction": self.budget.account_cap_fraction}
               if self.budget.account_cap_fraction is not None else {}),
            **({"ledger_accounting": self.budget.accounting} if self.budget.accounting != "rolling" else {}),
            "model": r.model,
            "call_id": rec.call_id,
            "source": rec.source,
            "outcome": rec.outcome,
            "status": rec.status,
            "est_prompt_tokens": r.est_prompt_tokens,
            "max_tokens": r.max_tokens,
            "reserved_tokens": r.reserved_tokens,
            "usage_total_tokens": usage_total,
            "charged_requests": req,
            "charged_tokens": tok,
            "charge_basis": basis,
            "hdr_remaining_requests": rec.header("x-ratelimit-remaining-requests"),
            "hdr_remaining_tokens": rec.header("x-ratelimit-remaining-tokens"),
            "extra": extra or {},
        }
        with self.path.open("a", encoding="utf-8", newline="\n") as f:
            f.write(json.dumps(entry, ensure_ascii=False) + "\n")
            f.flush()
        self.entries.append(entry)
        if rec.status == 401:
            # every further call would be rejected too; one is enough to know
            self.halted = "401 invalid API key: Groq rejected the key in .env; no further real calls"
        self._check_server_floor(rec)
        return entry

    def _check_server_floor(self, rec: CallRecord) -> None:
        frac = self.budget.min_remaining_requests_fraction
        if frac is None:
            return
        remaining = _int_header(rec, "x-ratelimit-remaining-requests")
        limit = _int_header(rec, "x-ratelimit-limit-requests")
        if remaining is not None and limit and remaining < frac * limit:
            self.halted = (f"server reports {remaining}/{limit} requests left today for {rec.model}, "
                           f"below the floor of {frac:.0%}; the shared key is being used elsewhere "
                           f"or the cap is wrong")

    def status(self) -> dict[str, Any]:
        out = {"window_hours": self.budget.window_hours, "halted": self.halted, "caps": {}}
        for cap in self.budget.caps:
            u = self.usage(cap)
            out["caps"][cap.name] = {
                "scope": cap.scope,
                "total_requests": f"{u['total_requests']}/{cap.total_requests}" if cap.total_requests else u["total_requests"],
                "models": {m: {"requests": f"{u['models'][m]['requests']}/{mc.requests}",
                               "tokens": f"{u['models'][m]['tokens']}/{mc.tokens}"}
                           for m, mc in cap.models.items()},
            }
        return out


class BudgetedClient:
    """The only way scripts should make real calls: reserve -> call -> settle."""

    def __init__(self, client: LLMClient, ledger: Ledger, scope: str,
                 raw_sink: Callable[[dict[str, Any]], None] | None = None) -> None:
        self.client = client
        self.ledger = ledger
        self.scope = scope
        self.raw_sink = raw_sink

    async def stream_chat(self, payload: dict[str, Any], *, phase: str, on_delta=None, timeouts=None,
                          extra: dict[str, Any] | None = None) -> CallRecord:
        r = self.ledger.reserve(payload, self.scope, phase)
        settled = False

        def sink(rec: CallRecord) -> None:
            nonlocal settled
            entry = self.ledger.settle(r, rec, extra)
            settled = True
            if self.raw_sink is not None:
                self.raw_sink({"phase": phase, "extra": extra or {}, "ledger": entry, "record": rec.to_dict()})

        try:
            return await self.client.stream_chat(payload, on_delta=on_delta, record_sink=sink, timeouts=timeouts)
        finally:
            if not settled:
                self.ledger.release(r)


def main() -> int:
    with Ledger(load_budget()) as led:
        print(json.dumps(led.status(), indent=2))
    return 0


if __name__ == "__main__":
    sys.exit(main())
